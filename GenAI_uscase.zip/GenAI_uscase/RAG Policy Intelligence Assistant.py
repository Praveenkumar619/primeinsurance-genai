# Databricks notebook source
# MAGIC %pip install sentence-transformers faiss-cpu
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

from pyspark.sql.functions import *

TABLE = "primeinsurance.gold.dim_policy"

df = spark.table(TABLE)
display(df.limit(5))

# COMMAND ----------

def row_to_text(r):
    return f"""
Policy Number: {r.get('policy_id')}

Coverage Tier: {r.get('coverage_tier')}
Deductible: {r.get('deductible')}
Bodily Injury Limit: {r.get('bodily_injury_limit')}
Property Damage Limit: {r.get('property_damage_limit')}
Umbrella Coverage: {r.get('umbrella_coverage')}
Policy Type: {r.get('policy_type')}

This policy provides {r.get('coverage_tier')} coverage with a deductible of {r.get('deductible')}.
Bodily injury is covered up to {r.get('bodily_injury_limit')} and property damage up to {r.get('property_damage_limit')}.
"""

docs = [row_to_text(r.asDict()) for r in df.collect()]
print(f" Created {len(docs)} documents")

# COMMAND ----------

def chunk_text(text, chunk_size=200):
    words = text.split()
    return [
        " ".join(words[i:i+chunk_size])
        for i in range(0, len(words), chunk_size)
    ]

chunks = []
for doc in docs:
    chunks.extend(chunk_text(doc))

print(f" Total chunks: {len(chunks)}")

# COMMAND ----------

from sentence_transformers import SentenceTransformer

model = SentenceTransformer("all-MiniLM-L6-v2")

embeddings = model.encode(chunks, show_progress_bar=True)

# COMMAND ----------

import faiss
import numpy as np

dimension = embeddings.shape[1]

index = faiss.IndexFlatL2(dimension)
index.add(np.array(embeddings))

print(f" FAISS index built with {index.ntotal} vectors")

# COMMAND ----------

def retrieve(query, top_k=3):
    q_emb = model.encode([query])
    
    distances, indices = index.search(np.array(q_emb), top_k)
    
    results = [chunks[i] for i in indices[0]]
    
    return results, distances[0]

# COMMAND ----------

from openai import OpenAI

client = OpenAI(
    api_key="dapi77f2c8025423a18ee31bd26e23b702c0",
    base_url=f"https://dbc-2eebb4e7-9396.cloud.databricks.com/serving-endpoints"
)

MODEL = "databricks-gpt-oss-20b"

# COMMAND ----------

def build_prompt(question, context_chunks):
    context = "\n\n".join(context_chunks)

    return f"""
You are an insurance policy assistant.

Use ONLY the information below to answer.

Context:
{context}

Instructions:
- Answer clearly
- ALWAYS mention policy numbers
- If multiple policies match, compare them
- If no answer, say "No policy found"

Question:
{question}
"""

# COMMAND ----------

def ask(question):
    retrieved, scores = retrieve(question, top_k=3)
    
    prompt = build_prompt(question, retrieved)
    
    response = client.chat.completions.create(
        model=MODEL,
        messages=[{"role": "user", "content": prompt}],
        temperature=0.2,
        max_tokens=500
    )
    
    answer = response.choices[0].message.content
    
    # simple confidence (inverse distance)
    confidence = float(1 / (1 + scores[0]))
    
    return answer, confidence, retrieved

# COMMAND ----------

from pyspark.sql import Row
from datetime import datetime

def log_query(question, answer, confidence, sources):
    row = Row(
        question=question,
        answer=answer,
        confidence_score=float(confidence),
        source_policies=" | ".join(sources),
        asked_at=datetime.now()
    )
    
    spark.createDataFrame([row]) \
        .write.format("delta") \
        .mode("append") \
        .saveAsTable("primeinsurance.gold.rag_query_history")

# COMMAND ----------

questions = [
    "What is the deductible for policy 123?",
    "Which policies have high coverage tier?",
    "Compare two policies with umbrella coverage",
    "Find policies with low deductible",
    "What policy covers highest bodily injury?"
]

for q in questions:
    ans, conf, src = ask(q)
    
    print(f"\nQ: {q}")
    print(f"A: {ans}")
    print(f"Confidence: {conf}")
    
    log_query(q, str(ans), conf, src)

# COMMAND ----------

# DBTITLE 1,Cell 13
display(spark.table("primeinsurance.gold.rag_query_history"))