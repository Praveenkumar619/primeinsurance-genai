# Databricks notebook source
# MAGIC %pip install -U mlflow
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

CATALOG = "primeinsurance"

SILVER_DB = f"{CATALOG}.silver"
GOLD_DB   = f"{CATALOG}.gold"

SOURCE_TABLE = f"{SILVER_DB}.claims"
TARGET_TABLE = f"{GOLD_DB}.claim_anomaly_explanations"

MODEL_NAME = "databricks-gpt-oss-20b"

print(f"""
Source : {SOURCE_TABLE}
Target : {TARGET_TABLE}
Model  : {MODEL_NAME}
""")

# COMMAND ----------

# DBTITLE 1,Cell 3
from pyspark.sql.functions import *

df = spark.table("primeinsurance.bronze.claims")

# Map actual column names from bronze.claims table
required_cols = [
    "ClaimID", "PolicyID", "Claim_Logged_On",
    "Claim_Processed_On", "incident_severity", "incident_type",
    "property", "vehicle", "bodily_injuries"
]

missing = [c for c in required_cols if c not in df.columns]

if missing:
    raise Exception(f"Missing columns: {missing}")

df = df.select(*required_cols)

# Create unified claim_amount from property + vehicle + bodily_injuries
# Handle 'NULL' strings before casting
df = df.withColumn("claim_amount", 
    coalesce(when(col("property") != "NULL", col("property").cast("double")), lit(0)) + 
    coalesce(when(col("vehicle") != "NULL", col("vehicle").cast("double")), lit(0)) + 
    coalesce(when(col("bodily_injuries") != "NULL", col("bodily_injuries").cast("double")), lit(0))
)

# Rename columns to match downstream code expectations
df = (df
    .withColumnRenamed("ClaimID", "claim_id")
    .withColumnRenamed("PolicyID", "customer_id")
    .withColumnRenamed("Claim_Logged_On", "claim_date")
    .withColumnRenamed("Claim_Processed_On", "settlement_date")
    .withColumnRenamed("incident_severity", "severity")
)

display(df.limit(5))

# COMMAND ----------

stats = df.agg(
    avg("claim_amount").alias("mean"),
    stddev("claim_amount").alias("std")
).first()

mean_val = stats["mean"]
std_val  = stats["std"] or 1

print(f"Mean={mean_val}, Std={std_val}")

# COMMAND ----------

from pyspark.sql.window import Window

w = Window.partitionBy("customer_id")

df_feat = (
    df
    .withColumn("z_score", (col("claim_amount") - mean_val) / std_val)
    .withColumn("claim_count", count("*").over(w))
    .withColumn("processing_days",
        coalesce(datediff(col("settlement_date"), col("claim_date")), lit(0))
    )
)

df_rules = (
    df_feat
    # Rules
    .withColumn("r1", (col("z_score") > 2.5).cast("int"))
    .withColumn("r2", (col("claim_amount") > 100000).cast("int"))
    .withColumn("r3", (col("claim_count") > 3).cast("int"))
    .withColumn("r4", (col("processing_days") < 1).cast("int"))
    .withColumn("r5", (col("processing_days") > 30).cast("int"))
    .withColumn("r6", (col("severity").isNull() | col("incident_type").isNull()).cast("int"))

    # Weighted score
    .withColumn("anomaly_score",
        col("r1")*30 + col("r2")*20 + col("r3")*15 +
        col("r4")*10 + col("r5")*10 + col("r6")*15
    )

    # Priority
    .withColumn("priority",
        when(col("anomaly_score") >= 60, "HIGH")
        .when(col("anomaly_score") >= 30, "MEDIUM")
        .otherwise("LOW")
    )

    # Triggered rules (clean)
    .withColumn("triggered_rules",
        array_remove(array(
            when(col("r1")==1, "High amount anomaly"),
            when(col("r2")==1, "Large claim"),
            when(col("r3")==1, "Repeat claimant"),
            when(col("r4")==1, "Fast processing"),
            when(col("r5")==1, "Delayed processing"),
            when(col("r6")==1, "Missing data")
        ), None)
    )
)

df_anomaly = df_rules.filter(col("anomaly_score") >= 30)

display(df_anomaly.limit(10))

# COMMAND ----------

from openai import OpenAI

client = OpenAI(
    api_key="dapi77f2c8025423a18ee31bd26e23b702c0",
    base_url="https://dbc-2eebb4e7-9396.cloud.databricks.com/serving-endpoints"
)

# COMMAND ----------

def build_prompt(r):
    return f"""
You are a fraud investigation analyst.

--- CLAIM ---
ID: {r['claim_id']}
Amount: {r['claim_amount']}
Severity: {r['severity']}
Incident: {r['incident_type']}
Processing Days: {r['processing_days']}
Score: {r['anomaly_score']}
Rules: {r['triggered_rules']}
------------

Respond EXACTLY in this format:

SUSPICION:
- (specific facts)

RISK FACTORS:
- (map to rules)

NEXT ACTIONS:
- (clear steps investigator must take)
"""

# COMMAND ----------

from pyspark.sql import Row
from datetime import datetime

batch_df = df_anomaly.limit(100)   # control size

results = []

for r in batch_df.toLocalIterator():   # better than collect()
    d = r.asDict()

    try:
        res = client.chat.completions.create(
            model=MODEL_NAME,
            messages=[{"role":"user","content":build_prompt(d)}],
            max_tokens=400,
            temperature=0.2
        )
        explanation = res.choices[0].message.content.strip()
        status = "success"
    except Exception as e:
        explanation = str(e)
        status = "failed"

    results.append(Row(
        claim_id=d["claim_id"],
        customer_id=d["customer_id"],
        claim_amount=d["claim_amount"],
        severity=d["severity"],
        incident_type=d["incident_type"],
        anomaly_score=d["anomaly_score"],
        priority=d["priority"],
        triggered_rules=",".join(d["triggered_rules"]) if d["triggered_rules"] else "",
        investigation_brief=explanation,
        generation_status=status,
        generated_at=datetime.now(),
        model_name=MODEL_NAME
    ))

df_final = spark.createDataFrame(results)

# COMMAND ----------

(df_final.write
    .format("delta")
    .mode("append")
    .option("mergeSchema","true")
    .saveAsTable(TARGET_TABLE)
)

print(" Gold table updated")

# COMMAND ----------

dbutils.widgets.removeAll()
dbutils.widgets.text("question","Show high risk claims","Ask question")

# COMMAND ----------

question = dbutils.widgets.get("question").lower()

df_gold = spark.table(TARGET_TABLE)

# Order by anomaly_score descending to get highest-risk claims first
df_ctx = df_gold.orderBy("anomaly_score", ascending=False).limit(30)

rows = df_ctx.collect()

context = "\n".join([
    f"Claim {r['claim_id']} | Score {r['anomaly_score']} | Priority {r['priority']} | {r['triggered_rules']}"
    for r in rows
])

# COMMAND ----------

response = client.chat.completions.create(
    model=MODEL_NAME,
    messages=[
        {
            "role":"system",
            "content":f"""
You are a fraud analyst.

Context:
{context}

Answer clearly and prioritize high-risk claims.
"""
        },
        {"role":"user","content":question}
    ],
    max_tokens=500,
    temperature=0.2
)

print("\n ANSWER:\n")
print(response.choices[0].message.content)

# COMMAND ----------

display(spark.table(TARGET_TABLE))