# Databricks notebook source
# MAGIC %pip install openai
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

import os

DATABRICKS_TOKEN = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()
DATABRICKS_HOST  = spark.conf.get("spark.databricks.workspaceUrl")

os.environ["DATABRICKS_TOKEN"] = "dapi77f2c8025423a18ee31bd26e23b702c0"
os.environ["DATABRICKS_HOST"]  = f"https://dbc-2eebb4e7-9396.cloud.databricks.com/editor/notebooks/3837244345869657?o=3911621209728388#command/6564309539110934"

MODEL_NAME   = "databricks-gpt-oss-20b"


print("Config ready")

# COMMAND ----------

from pyspark.sql.functions import col

SOURCE_TABLE = "primeinsurance.silver.quality_log"
TARGET_TABLE = "primeinsurance.gold.dq_explanation_report"

df_issues = spark.table(SOURCE_TABLE)

# Get already processed issue_ids
if spark.catalog.tableExists(TARGET_TABLE):
    df_processed = spark.table(TARGET_TABLE).select("issue_id").distinct()
    df_new = df_issues.join(df_processed, "issue_id", "left_anti")
else:
    df_new = df_issues

print(f"Total issues: {df_issues.count()}")
print(f"New issues to process: {df_new.count()}")

display(df_new.limit(5))

# COMMAND ----------

display(spark.table("primeinsurance.silver.quality_log"))

# COMMAND ----------

from openai import OpenAI
import time

client = OpenAI(
    api_key=DATABRICKS_TOKEN,
    base_url=f"https://{DATABRICKS_HOST}/serving-endpoints"
)

MODEL_NAME = "databricks-gpt-oss-20b"

def build_prompt(row: dict) -> str:
    return f"""
You are a data quality analyst explaining issues to a compliance team.

--- ISSUE DETAILS ---
Table: {row.get("table_name")}
Column: {row.get("column_name")}
Issue Type: {row.get("issue_type")}
Severity: {row.get("severity")}
Affected Records: {row.get("affected_records")}
Affected Ratio: {row.get("affected_ratio")}
Detected At: {row.get("detected_at")}
Details: {row.get("details")}
---------------------

Respond in this structure:

**What was found:**
...

**Why it matters:**
...

**Root cause:**
...

**Fix applied:**
...

**Prevention:**
...
""".strip()


def explain_with_retry(row_dict, retries=3):
    for attempt in range(retries):
        try:
            prompt = build_prompt(row_dict)

            response = client.chat.completions.create(
                model=MODEL_NAME,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=800,
                temperature=0.2
            )

            return {
                "explanation": response.choices[0].message.content.strip(),
                "generation_status": "success"
            }

        except Exception as e:
            time.sleep(2)

            if attempt == retries - 1:
                return {
                    "explanation": f"ERROR: {str(e)}",
                    "generation_status": "failed"
                }

print("LLM function with retry ready")

# COMMAND ----------

# DBTITLE 1,Cell 6
from pyspark.sql import Row
from pyspark.sql.types import (
    StructType, StructField, StringType, LongType, DoubleType, TimestampType
)
from datetime import datetime, timezone

BATCH_SIZE = 20   # Keep small to avoid overload

rows = df_new.limit(500).collect()   # Limit for safety in free edition

print(f" Processing {len(rows)} issues in batches of {BATCH_SIZE}")

results = []

for i in range(0, len(rows), BATCH_SIZE):
    batch = rows[i:i+BATCH_SIZE]
    print(f"Processing batch {i//BATCH_SIZE + 1}")

    for row in batch:
        row_dict = row.asDict()

        llm_result = explain_with_retry(row_dict)

        results.append(Row(
            issue_id=row_dict.get("issue_id"),
            table_name=row_dict.get("table_name"),
            column_name=row_dict.get("column_name"),
            issue_type=row_dict.get("issue_type"),
            severity=row_dict.get("severity"),
            affected_records=row_dict.get("affected_records"),
            affected_ratio=row_dict.get("affected_ratio"),
            detected_at=row_dict.get("detected_at"),

            explanation=llm_result["explanation"],
            generation_status=llm_result["generation_status"],
            generated_at=datetime.now(timezone.utc).isoformat(),
            model_name=MODEL_NAME
        ))

print(f" Completed processing {len(results)} issues")

schema = StructType([
    StructField("issue_id", StringType(), True),
    StructField("table_name", StringType(), True),
    StructField("column_name", StringType(), True),
    StructField("issue_type", StringType(), True),
    StructField("severity", StringType(), True),
    StructField("affected_records", LongType(), True),
    StructField("affected_ratio", DoubleType(), True),
    StructField("detected_at", TimestampType(), True),
    StructField("explanation", StringType(), True),
    StructField("generation_status", StringType(), True),
    StructField("generated_at", StringType(), True),
    StructField("model_name", StringType(), True)
])

df_results = spark.createDataFrame(results, schema=schema)
display(df_results.limit(5))

# COMMAND ----------

(df_results
    .write
    .format("delta")
    .mode("append")
    .option("mergeSchema", "true")
    .saveAsTable(TARGET_TABLE)
)

print(f" Data written to {TARGET_TABLE}")
print(f" Rows written: {df_results.count()}")

# COMMAND ----------

# DBTITLE 1,Cell 8
from pyspark.sql.functions import col

GOLD_TABLE = "primeinsurance.gold.dq_explanation_report"

dbutils.widgets.text("question", "", "Enter your question")
question = dbutils.widgets.get("question").lower()

# Simple keyword-based filtering (lightweight RAG)
filtered_df = spark.table(GOLD_TABLE)

if "customer" in question:
    filtered_df = filtered_df.filter(col("table_name").like("%customer%"))

if "claim" in question:
    filtered_df = filtered_df.filter(col("table_name").like("%claim%"))

# Limit context size
filtered_df = filtered_df.orderBy(col("severity").desc()).limit(50)

rows = filtered_df.collect()

issue_context = ""
for r in rows:
    issue_context += f"""
Issue: {r['issue_id']}
Table: {r['table_name']}
Severity: {r['severity']}
Explanation: {r['explanation']}
"""

print(f" Context size: {len(rows)} issues")

# COMMAND ----------

